<?php 
$data = file_get_contents("https://www.jessoreboard.gov.bd/");

echo $data;

?>