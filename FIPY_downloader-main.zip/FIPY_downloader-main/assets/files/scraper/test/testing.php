<div class="bf" id="m-timeline-cover-section" bis_skin_checked="1">
    <div class="bq acw br" bis_skin_checked="1">
        <div class="_52ja cg ch ci" bis_skin_checked="1">
            পৃথিবীটা মানুষের হোক <br />
            ধর্ম থাকুক অন্তরে <br />
            মসজিদে আজান হোক <br />
            ঘন্টা বাজুক মন্দিরে...
        </div>
    </div>
</div>
