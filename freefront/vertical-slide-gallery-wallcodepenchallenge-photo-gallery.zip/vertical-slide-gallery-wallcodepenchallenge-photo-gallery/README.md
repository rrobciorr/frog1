# Vertical Slide Gallery Wall - #CodePenChallenge: Photo Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/DeyJordan/pen/LYMNOwV](https://codepen.io/DeyJordan/pen/LYMNOwV).

